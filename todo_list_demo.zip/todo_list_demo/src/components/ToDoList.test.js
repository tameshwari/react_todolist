import { render, screen } from '@testing-library/react';
import ToDoList from './ToDoList';

test('should take a snapshot', () => {
 const element=  render(<ToDoList />);
  expect(element).toMatchSnapshot();
});

// test('should render element', () => {
//    render(<ToDoList />);
//      const linkElement = screen.getByText("todo-button");
//      expect(linkElement).toBeInTheDocument();
//    });
   