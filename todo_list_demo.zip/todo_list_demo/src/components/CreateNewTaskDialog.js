import React, { useState, useCallback, useEffect } from "react";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogTitle from "@material-ui/core/DialogTitle";
import Dialog from "@material-ui/core/Dialog";
import Button from "@material-ui/core/Button";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const CreateNewTaskDialog = (props) => {
  const [input, setInput] = useState("");
  const [expiryDate, setExpiryDate] = useState(new Date());

  const { onDialogCallback, open, onSubmit, selectedTask } = props;

  useEffect(() => {
    if (selectedTask.id != null) {
      setInput(selectedTask.value);
      setExpiryDate(new Date(selectedTask.date))
    }
  }, [selectedTask]);

  const OnDialogButtonClick = () => {
    onDialogCallback();
  };

  const handleChange = (e) => {
    setInput(e.target.value);
  };

  const handleDateChange = (date) => {
    setExpiryDate(date);
  };

  const checkForPriorityTask = () => {
    const then = new Date(expiryDate);
    const now = new Date();
    const msBetweenDates = Math.abs(then.getTime() - now.getTime());
    const hoursBetweenDates = msBetweenDates / (60 * 60 * 1000);
    console.log(hoursBetweenDates);

    return hoursBetweenDates < 24 ? true : false;
  };

  const handleSubmit = useCallback(
    (e) => {
      onDialogCallback();
      e.preventDefault();
      const dateWithinHours = checkForPriorityTask();
      const dateString = new Date(expiryDate).toDateString();
      onSubmit({
        id: selectedTask.id || Math.floor(Math.random() * 10000),
        text: input,
        date: dateString,
        updatedDate: new Date(),
        dateWithinHours: dateWithinHours,
      });
      setInput("");
      setExpiryDate(new Date());
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [onDialogCallback, onSubmit, input, selectedTask, expiryDate]
  );

  return (
    <>
      <Dialog open={open} onClose={OnDialogButtonClick}>
        <DialogTitle>New task</DialogTitle>
        <DialogContent style={{ minHeight: "280px" }}>
          <input
            placeholder="Title"
            value={input}
            onChange={handleChange}
            name="text"
            className="todo-input"
            maxLength={50}
          />
          <div className="todo-datePicker">
            <span> Expiry Date</span>
            <DatePicker
              selected={expiryDate}
              onChange={handleDateChange}
              name="expiryDate"
              dateFormat="MM/dd/yyyy"
              minDate={new Date()}
            />
          </div>
        </DialogContent>
        <DialogActions>
          <Button color="primary" onClick={OnDialogButtonClick}>
            Close
          </Button>
          <Button color="primary" autoFocus onClick={handleSubmit}>
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default CreateNewTaskDialog;
