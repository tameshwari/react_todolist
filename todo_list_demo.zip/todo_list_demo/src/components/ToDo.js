import { RiCloseCircleLine } from "react-icons/ri";
import { TiEdit } from "react-icons/ti";

const Todo = ({ todos, completeTodo, removeTodo, updateTodo }) => {
  const handleEditTask = (todo) => {
    updateTodo(todo.id, todo.text, todo.date);
  };

  return todos?.map((todo, index) => (
    <div
      className={todo?.isComplete ? "todo-row complete" : todo?.dateWithinHours ? "todo-row heilight": "todo-row"}
      key={index}
    >
      <div key={todo.id} onClick={() => completeTodo(todo.id)}>
        <span >{todo.text} </span>
        <span style={{ paddingLeft: "50px" }}> Expiry Date: {todo.date}</span>
      </div>

      <div className="icons">
        <RiCloseCircleLine
          onClick={() => removeTodo(todo.id)}
          className="delete-icon"
        />
        <TiEdit onClick={() => handleEditTask(todo)} className="edit-icon" />
      </div>
    </div>
  ));
};

export default Todo;
