import React, { useState, useCallback, useEffect } from "react";
import CreateNewTaskDialog from "./CreateNewTaskDialog";
import Todo from "./ToDo";

function TodoList() {
  const [taskList, setTaskList] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedTask, setSelectedTask] = useState({
    id: null,
    value: "",
    date: null,
  });

  useEffect(() => {
    const list = localStorage.getItem("taskList");
    if (list) {
      setTaskList(JSON.parse(list));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    localStorage.setItem("taskList", JSON.stringify(taskList));
  }, [taskList]);

  const addOrEditTask = (task) => {
    if (selectedTask.id != null) {
      setTaskList((prev) =>
        prev
          .map((item) => (item.id === selectedTask.id ? task : item))
          .sort((task1, task2) => {
            return task1.updatedDate < task2.updatedDate ? 1 : -1;
          })
      );
      setSelectedTask({
        id: null,
        value: "",
        date: null,
      });
    } else {
      const newTodos = [task, ...taskList];
      setTaskList(newTodos);
    }
  };

  const handleDialog = useCallback(() => {
    setOpenDialog(!openDialog);
  }, [openDialog]);

  const updateSelectedTask = (todoId, newValue, date) => {
    setSelectedTask({
      id: todoId,
      value: newValue,
      date: date,
    });
    setOpenDialog(true);
  };

  const removeSelectedTask = (id) => {
    const removedArr = [...taskList].filter((task) => task.id !== id);

    setTaskList(removedArr);
  };

  const completeSelectedTask = (id) => {
    let updatedTodos = taskList.map((task) => {
      if (task.id === id) {
        task.isComplete = !task.isComplete;
      }
      return task;
    });
    setTaskList(updatedTodos);
  };

  const handleSubmit = (e) => {
    setOpenDialog(true);
  };

  return (
    <>
      <div style={{ padding: "50px" }}>
        <h1 className="todo-header">My Task list</h1>
        <button
          onClick={handleSubmit}
          className="todo-button"
          text={"todo-button"}
        >
          Add New task
        </button>
      </div>
      <CreateNewTaskDialog
        selectedTask={selectedTask}
        open={openDialog}
        onDialogCallback={handleDialog}
        onSubmit={addOrEditTask}
      />
      { taskList.length > 0 ?
      <Todo
        todos={taskList}
        completeTodo={completeSelectedTask}
        removeTodo={removeSelectedTask}
        updateTodo={updateSelectedTask}
      /> : <span style={{color: 'white'}}>There is no task added, Please click on Add New task to add task.</span>
}
    </>
  );
}

export default TodoList;
